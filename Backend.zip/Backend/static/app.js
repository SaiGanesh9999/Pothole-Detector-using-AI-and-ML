let complaintData = [];
let solvedComplaints = [];
let complaintMap;
let complaintMapMarkers = [];

function severityStyles(level) {
  if (level === "Dangerous") return "bg-red-500 text-white";
  if (level === "Moderate") return "bg-amber-400 text-white";
  return "bg-emerald-500 text-white";
}

function createDiamondIcon(color) {
  return L.divIcon({
    className: "custom-diamond-marker",
    html: `<div style="width:18px;height:18px;background:${color};transform:rotate(45deg);border-radius:2px;border:2px solid white;box-shadow:0 4px 10px; rgba(15,23,42,0.25);"></div>`,
    iconSize: [18, 18],
    iconAnchor: [9, 9]
  });
}

function createAccidentIcon() {
  return L.divIcon({
    className: "custom-accident-marker",
    html: '<div style="width:28px;height:28px;border-radius:6px;background:#000;color:#fff;display:flex;align-items:center;justify-content:center;font-weight:800;font-size:14px;border:2px solid white;box-shadow:0 4px 10px rgba(15,23,42,0.25);">A</div>',
    iconSize: [28, 28],
    iconAnchor: [14, 14]
  });
}

async function fetchSession() {
  const res = await fetch("/api/session");
  const data = await res.json();

  const loginGate = document.getElementById("loginGate");
  const mainContent = document.getElementById("mainContent");

  if (data.logged_in) {
    loginGate.classList.add("hidden");
    mainContent.classList.remove("hidden");
  } else {
    loginGate.classList.remove("hidden");
    mainContent.classList.add("hidden");
  }
}

async function handleUserLogin(e) {
  e.preventDefault();

  const email = document.getElementById("gateUserEmail").value;
  const password = document.getElementById("gateUserPassword").value;
  const message = document.getElementById("gateUserMessage");

  const res = await fetch("/api/login/user", {
    method: "POST",
    headers: {"Content-Type": "application/json"},
    body: JSON.stringify({ email, password })
  });

  const data = await res.json();
  message.textContent = data.message;

  if (data.success) {
    await fetchSession();
    await loadAllData();
  }
}

async function handleAdminLogin(e) {
  e.preventDefault();

  const email = document.getElementById("gateAdminEmail").value;
  const password = document.getElementById("gateAdminPassword").value;
  const message = document.getElementById("gateAdminMessage");

  const res = await fetch("/api/login/admin", {
    method: "POST",
    headers: {"Content-Type": "application/json"},
    body: JSON.stringify({ email, password })
  });

  const data = await res.json();
  message.textContent = data.message;

  if (data.success) {
    await fetchSession();
    await loadAllData();
  }
}

async function handleLogout() {
  await fetch("/api/logout", { method: "POST" });
  location.reload();
}

async function fetchPotholes() {
  const res = await fetch("/api/potholes");
  complaintData = await res.json();
}

async function fetchSolved() {
  const res = await fetch("/api/solved");
  solvedComplaints = await res.json();
}

async function fetchStats() {
  const res = await fetch("/api/stats");
  const stats = await res.json();

  const pieTotal = document.getElementById("pieTotal");
  const minorValue = document.getElementById("minorValue");
  const moderateValue = document.getElementById("moderateValue");
  const severeValue = document.getElementById("severeValue");

  const total = stats.unsolved_complaints ?? stats.pending_action ?? stats.total_complaints ?? 0;
  const minor = stats.severity.minor || 0;
  const moderate = stats.severity.moderate || 0;
  const severe = stats.severity.severe || 0;

  pieTotal.textContent = total;
  minorValue.textContent = `${minor}`;
  moderateValue.textContent = `${moderate}`;
  severeValue.textContent = `${severe}`;
}

function renderRecentComplaints() {
  const list = document.getElementById("recentComplaintsList");
  if (!list) return;

  list.innerHTML = "";

  complaintData.forEach(item => {
    const card = document.createElement("article");
    card.className = "overflow-hidden rounded-[22px] border border-slate-200 bg-white shadow-sm transition hover:-translate-y-0.5 hover:shadow-md cursor-pointer";
    card.onclick = () => updateComplaintDetails(item.id);

    card.innerHTML = `
      <div class="relative">
        <img src="${item.image}" alt="${item.title}" class="h-40 w-full object-cover" loading="lazy">
        <div class="absolute right-3 top-3 flex flex-col items-end gap-1.5">
          <span class="rounded-full px-3 py-1 text-[11px] font-extrabold uppercase tracking-[0.04em] ${severityStyles(item.severity)} shadow-sm">${item.severity}</span>
          ${item.accident ? '<span class="rounded-full bg-black px-3 py-1 text-[11px] font-extrabold uppercase tracking-[0.04em] text-white shadow-sm">Accident</span>' : ''}
        </div>
      </div>
      <div class="p-4">
        <p class="text-[1.05rem] font-extrabold leading-tight text-slate-800">${item.title}</p>
        <p class="mt-1 text-sm leading-6 text-slate-600">${item.address}</p>
        <div class="mt-1 text-xs leading-5 text-slate-500">
          <p>Lat: ${Number(item.lat).toFixed(4)} | Lng: ${Number(item.lng).toFixed(4)}</p>
        </div>
        <div class="mt-3 flex flex-wrap items-center justify-between gap-2">
          <p class="text-sm font-semibold text-slate-500">${item.date}</p>
          <span class="rounded-full bg-slate-100 px-3 py-1 text-[11px] font-bold text-slate-600">${item.status}</span>
        </div>
      </div>
    `;
    list.appendChild(card);
  });
}

function renderSolvedComplaints() {
  const container = document.getElementById("solvedList");
  if (!container) return;

  container.innerHTML = "";

  solvedComplaints.forEach(item => {
    const card = document.createElement("div");
    card.className = "rounded-[22px] border border-emerald-100 bg-white p-5 shadow-sm";
    card.innerHTML = `
      <div class="flex items-center justify-between gap-3">
        <h3 class="text-lg font-extrabold text-slate-800">${item.title}</h3>
        <span class="rounded-full bg-emerald-100 px-3 py-1 text-xs font-bold text-emerald-700">${item.status}</span>
      </div>
      <p class="mt-2 text-sm text-slate-600">${item.location}</p>
      <p class="mt-3 text-xs font-semibold text-slate-500">${item.time}</p>
    `;
    container.appendChild(card);
  });
}

function renderMapPins() {
  const mapNode = document.getElementById("complaintMap");
  if (!mapNode || typeof L === "undefined") return;

  if (complaintMap) {
    complaintMap.remove();
    complaintMap = null;
    complaintMapMarkers = [];
  }

  complaintMap = L.map("complaintMap").setView([16.9891, 82.2475], 13);

  L.tileLayer("https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png", {
    maxZoom: 19,
    attribution: "&copy; OpenStreetMap contributors"
  }).addTo(complaintMap);

  complaintData.forEach(item => {
    const color =
      item.severity === "Dangerous" ? "#ef4444" :
      item.severity === "Moderate" ? "#f59e0b" : "#22c55e";

    const marker = L.marker([item.lat, item.lng], {
      icon: item.accident ? createAccidentIcon() : createDiamondIcon(color)
    }).addTo(complaintMap);

    marker.bindPopup(`
      <div style="min-width:180px">
        <div style="font-weight:800;color:#0f172a;margin-bottom:4px;">${item.title}</div>
        <div style="font-size:12px;color:#475569;line-height:1.5;">${item.address}</div>
        <div style="margin-top:8px;font-size:12px;font-weight:700;color:#334155;">${item.severity} • ${item.status}</div>
      </div>
    `);

    complaintMapMarkers.push({ id: item.id, marker });
  });
}

function updateComplaintDetails(id) {
  const found = complaintData.find(c => c.id === id);
  const markerObj = complaintMapMarkers.find(m => m.id === id);

  if (found && markerObj && complaintMap) {
    complaintMap.setView([found.lat, found.lng], 14);
    markerObj.marker.openPopup();
  }
}

async function handleFeedbackSubmit(e) {
  e.preventDefault();

  const payload = {
    name: document.getElementById("name").value,
    email: document.getElementById("email").value,
    role: document.getElementById("role").value,
    issue: document.getElementById("issue").value,
    message: document.getElementById("message").value
  };

  const res = await fetch("/api/feedback", {
    method: "POST",
    headers: {"Content-Type": "application/json"},
    body: JSON.stringify(payload)
  });

  const data = await res.json();
  document.getElementById("feedbackMessage").textContent = data.message;

  if (data.success) {
    document.getElementById("feedbackForm").reset();
  }
}

async function loadAllData() {
  await fetchPotholes();
  await fetchSolved();
  await fetchStats();
  renderRecentComplaints();
  renderSolvedComplaints();
  renderMapPins();
}

function setupNavigation() {
  const buttons = document.querySelectorAll("[data-target]");
  const sections = document.querySelectorAll(".page-section");

  buttons.forEach(btn => {
    btn.addEventListener("click", () => {
      const target = btn.getAttribute("data-target");
      if (!target) return;

      sections.forEach(sec => sec.classList.remove("active"));
      const targetSection = document.getElementById(target);
      if (targetSection) targetSection.classList.add("active");

      document.querySelectorAll(".nav-link").forEach(n => n.classList.remove("active"));
      if (btn.classList.contains("nav-link")) btn.classList.add("active");
    });
  });
}

document.addEventListener("DOMContentLoaded", async () => {
  lucide.createIcons();

  document.getElementById("gateUserForm")?.addEventListener("submit", handleUserLogin);
  document.getElementById("gateAdminForm")?.addEventListener("submit", handleAdminLogin);
  document.getElementById("feedbackForm")?.addEventListener("submit", handleFeedbackSubmit);
  document.getElementById("logoutBtn")?.addEventListener("click", handleLogout);
  document.getElementById("mobileLogoutBtn")?.addEventListener("click", handleLogout);

  setupNavigation();
  await fetchSession();
  await loadAllData();
});