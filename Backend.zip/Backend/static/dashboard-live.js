async function loadHomeSummary() {
  try {
    const res = await fetch("/api/home-summary");
    const data = await res.json();

    const complaintsTodayValue = document.getElementById("complaintsTodayValue");
    const severeCasesValue = document.getElementById("severeCasesValue");
    const solvedThisWeekValue = document.getElementById("solvedThisWeekValue");

    if (complaintsTodayValue) complaintsTodayValue.textContent = data.complaintsToday ?? 0;
    if (severeCasesValue) severeCasesValue.textContent = data.severeCases ?? 0;
    if (solvedThisWeekValue) solvedThisWeekValue.textContent = data.solvedThisWeek ?? 0;
  } catch (e) {
    console.error("Home summary load failed:", e);
  }
}

async function loadTopStats() {
  try {
    const res = await fetch("/api/stats");
    const data = await res.json();

    const totalPredictionsValue = document.getElementById("totalPredictionsValue");
    const accuracyRateValue = document.getElementById("accuracyRateValue");
    const totalComplaintsValue = document.getElementById("totalComplaintsValue");
    const pendingActionValue = document.getElementById("pendingActionValue");

    if (totalPredictionsValue) totalPredictionsValue.textContent = data.total_predictions ?? 0;
    if (accuracyRateValue) accuracyRateValue.textContent = `${data.accuracy_rate ?? 0}%`;
    if (totalComplaintsValue) totalComplaintsValue.textContent = data.unsolved_complaints ?? data.pending_action ?? data.total_complaints ?? 0;
    if (pendingActionValue) pendingActionValue.textContent = `${data.pending_action ?? 0} pending action`;
  } catch (e) {
    console.error("Stats load failed:", e);
  }
}

document.addEventListener("DOMContentLoaded", async () => {
  await loadHomeSummary();
  await loadTopStats();
});