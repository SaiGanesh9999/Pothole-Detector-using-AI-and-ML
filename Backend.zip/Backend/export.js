const admin = require("firebase-admin");
const createCsvWriter = require("csv-writer").createObjectCsvWriter;

const serviceAccount = require("./serviceAccountKey.json");

admin.initializeApp({
  credential: admin.credential.cert(serviceAccount)
});

const db = admin.firestore();

async function exportData() {
  try {
    const snapshot = await db.collection("potholes").get();

    if (snapshot.empty) {
      console.log("No data found in potholes collection.");
      return;
    }

    const records = [];

    snapshot.forEach((doc) => {
      const data = doc.data();

      records.push({
        address: data.address || "",
        latitude: data.latitude ?? "",
        longitude: data.longitude ?? "",
        confidence: data.confidence ?? "",
        timestamp: data.timestamp || "",
        detectedAtMillis: data.detectedAtMillis ?? "",
        detectionLabel: data.detectionLabel || "",
        id: data.id || doc.id || "",
        imageLocalPath: data.imageLocalPath || "",
        resolved: data.resolved ?? false,
        severity: data.severity || "",
        status: data.status || ""
      });
    });

    const csvWriter = createCsvWriter({
      path: "potholes_selected_fields.csv",
      header: [
        { id: "address", title: "ADDRESS" },
        { id: "latitude", title: "LATITUDE" },
        { id: "longitude", title: "LONGITUDE" },
        { id: "confidence", title: "CONFIDENCE" },
        { id: "timestamp", title: "TIMESTAMP" },
        { id: "detectedAtMillis", title: "DETECTED_AT_MILLIS" },
        { id: "detectionLabel", title: "DETECTION_LABEL" },
        { id: "id", title: "ID" },
        { id: "imageLocalPath", title: "IMAGE_LOCAL_PATH" },
        { id: "resolved", title: "RESOLVED" },
        { id: "severity", title: "SEVERITY" },
        { id: "status", title: "STATUS" }
      ]
    });

    await csvWriter.writeRecords(records);
    console.log("Data exported successfully to potholes_selected_fields.csv");
  } catch (error) {
    console.error("Error exporting data:", error);
  }
}

exportData();