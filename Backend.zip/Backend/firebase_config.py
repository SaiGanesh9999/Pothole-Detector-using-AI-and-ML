import os
import json
import firebase_admin
from firebase_admin import credentials, firestore

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
SERVICE_ACCOUNT_PATH = os.path.join(BASE_DIR, "serviceAccountKey.json")

if not os.path.exists(SERVICE_ACCOUNT_PATH):
    raise FileNotFoundError(f"serviceAccountKey.json not found at: {SERVICE_ACCOUNT_PATH}")

with open(SERVICE_ACCOUNT_PATH, "r", encoding="utf-8") as f:
    service_account_info = json.load(f)

PROJECT_ID = service_account_info.get("project_id")
CLIENT_EMAIL = service_account_info.get("client_email")

if not firebase_admin._apps:
    cred = credentials.Certificate(SERVICE_ACCOUNT_PATH)
    firebase_admin.initialize_app(cred, {
        "projectId": PROJECT_ID
    })

db = firestore.client()

print(f"[FIREBASE] Connected project_id = {PROJECT_ID}")
print(f"[FIREBASE] Service account = {CLIENT_EMAIL}")