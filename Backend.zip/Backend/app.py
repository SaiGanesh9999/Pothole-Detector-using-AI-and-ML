from flask import Flask, jsonify, render_template, request, session, send_from_directory
from flask_cors import CORS
from datetime import datetime, timedelta
from pathlib import Path
from werkzeug.utils import secure_filename
import base64
import os

from firebase_config import db

app = Flask(__name__)
app.secret_key = "pothole_secret_key"
CORS(app, supports_credentials=True)

ADMIN = {"email": "admin@gmail.com", "password": "123456"}
CONSTRUCTOR = {"email": "constructor@gmail.com", "password": "123456"}

POTHOLE_COLLECTION_CANDIDATES = ("potholes", "data")

BASE_DIR = Path(__file__).resolve().parent
UPLOAD_ROOT = BASE_DIR / "static" / "uploads"
REPORT_UPLOAD_DIR = UPLOAD_ROOT / "reports"
REPAIR_UPLOAD_DIR = UPLOAD_ROOT / "repairs"
ID_UPLOAD_DIR = UPLOAD_ROOT / "authority_ids"

REPORT_UPLOAD_DIR.mkdir(parents=True, exist_ok=True)
REPAIR_UPLOAD_DIR.mkdir(parents=True, exist_ok=True)
ID_UPLOAD_DIR.mkdir(parents=True, exist_ok=True)

ALLOWED_EXTENSIONS = {"png", "jpg", "jpeg", "webp"}


def request_payload():
    if request.is_json:
        return request.get_json(silent=True) or {}

    data = {}
    if request.form:
        data.update(request.form.to_dict())
    if not data:
        data.update(request.get_json(silent=True) or {})
    return data


def normalize_public_image_url(value: str, preferred_folder: str | None = None) -> str:
    raw = str(value or "").strip()
    if not raw:
        return ""

    lowered = raw.lower()
    if lowered.startswith(("http://", "https://", "data:image/", "/uploads/", "/static/")):
        return raw

    normalized = raw.replace('\\', '/')

    for token in ('/uploads/', 'uploads/', '/static/uploads/', 'static/uploads/'):
        if token in normalized:
            suffix = normalized.split(token, 1)[1].lstrip('/')
            return f"/uploads/{suffix}"

    basename = Path(normalized).name
    if not basename:
        return ""

    folders = [preferred_folder] if preferred_folder else []
    folders += ['reports', 'repairs', 'authority_ids']

    seen = set()
    for folder in folders:
        if not folder or folder in seen:
            continue
        seen.add(folder)
        file_path = UPLOAD_ROOT / folder / basename
        if file_path.exists():
            return build_local_file_url(folder, basename)

    return ""


def allowed_file(filename: str) -> bool:
    return "." in filename and filename.rsplit(".", 1)[1].lower() in ALLOWED_EXTENSIONS


def build_local_file_url(folder: str, filename: str) -> str:
    return f"/uploads/{folder}/{filename}"


def save_uploaded_file(file_storage, folder: str) -> str:
    if not file_storage or not getattr(file_storage, "filename", ""):
        return ""

    original_name = secure_filename(file_storage.filename)
    if not original_name:
        return ""

    if not allowed_file(original_name):
        raise ValueError("Only png, jpg, jpeg and webp files are allowed")

    extension = original_name.rsplit(".", 1)[1].lower()
    unique_name = f"{datetime.utcnow().strftime('%Y%m%d%H%M%S%f')}.{extension}"

    if folder == "reports":
        target_dir = REPORT_UPLOAD_DIR
    elif folder == "authority_ids":
        target_dir = ID_UPLOAD_DIR
    else:
        target_dir = REPAIR_UPLOAD_DIR

    target_path = target_dir / unique_name
    file_storage.save(target_path)
    return build_local_file_url(folder, unique_name)


def save_base64_image(data_url: str, folder: str) -> str:
    if not data_url or not isinstance(data_url, str) or "," not in data_url:
        return ""

    header, encoded = data_url.split(",", 1)
    if "image/" not in header:
        return ""

    mime = header.split(";")[0].split(":")[-1].lower()
    extension = mime.split("/")[-1]
    if extension == "jpg":
        extension = "jpeg"

    if extension not in ALLOWED_EXTENSIONS:
        raise ValueError("Unsupported image format")

    binary = base64.b64decode(encoded)
    unique_name = f"{datetime.utcnow().strftime('%Y%m%d%H%M%S%f')}.{extension}"

    if folder == "reports":
        target_dir = REPORT_UPLOAD_DIR
    elif folder == "authority_ids":
        target_dir = ID_UPLOAD_DIR
    else:
        target_dir = REPAIR_UPLOAD_DIR

    target_path = target_dir / unique_name
    with open(target_path, "wb") as fp:
        fp.write(binary)

    return build_local_file_url(folder, unique_name)


def get_user_by_email(email):
    docs = db.collection("users").where("email", "==", email).limit(1).stream()
    for doc in docs:
        data = doc.to_dict() or {}
        data["id"] = doc.id
        return data
    return None


def normalize_authority_approval_status(user):
    status = str((user or {}).get("approvalStatus", "")).strip().lower()
    if status in {"approved", "pending", "rejected"}:
        return status

    role = str((user or {}).get("role", "")).strip().lower()
    if role in {"constructor", "authority", "road_constructor"}:
        return "approved"

    return ""


def set_login_session(email: str, role: str):
    session["user"] = email
    session["role"] = role


def require_role(*roles):
    current_role = session.get("role")
    return current_role in roles


def safe_float(value, default=0.0):
    try:
        if value in (None, ""):
            return default
        return float(value)
    except (TypeError, ValueError):
        return default


def parse_doc_datetime(data):
    timestamp = data.get("timestamp")

    # Firestore timestamp handling (FIXED)
    if timestamp:
        try:
            # Firebase Admin returns datetime directly
            if isinstance(timestamp, datetime):
                return timestamp

            # Sometimes timestamp may have _seconds (rare cases)
            if hasattr(timestamp, "seconds"):
                return datetime.fromtimestamp(timestamp.seconds)

        except Exception:
            pass

    # fallback: detectedAtMillis
    if data.get("detectedAtMillis"):
        try:
            return datetime.fromtimestamp(float(data["detectedAtMillis"]) / 1000.0)
        except Exception:
            pass

    # fallback: string parsing
    for key in ("date", "timestampText", "created_at", "updated_at", "resolvedAt"):
        value = data.get(key)
        if not value:
            continue

        if isinstance(value, datetime):
            return value

        if isinstance(value, str):
            for fmt in ("%Y-%m-%d %H:%M:%S", "%Y-%m-%dT%H:%M:%S.%f"):
                try:
                    return datetime.strptime(value, fmt)
                except:
                    continue

    return datetime.now()

def normalize_status(value, resolved=False):
    text = str(value or "").strip().lower()
    if resolved or text in {"solved", "resolved", "completed", "complete", "closed", "done"}:
        return "Solved"
    if text in {"in progress", "working", "assigned", "accepted"}:
        return "In Progress"
    return "Pending"


def get_valid_image_url(data):
    candidates = [
        data.get("image"),
        data.get("imageUrl"),
        data.get("photo"),
        data.get("potholeImage"),
        data.get("complaintImage"),
        data.get("image_path"),
        data.get("imageLocalPath"),
        data.get("reportImage"),
        data.get("reportImageUrl"),
    ]

    for value in candidates:
        resolved = normalize_public_image_url(value, preferred_folder="reports")
        if resolved:
            return resolved

    return ""


def normalize_pothole(doc):
    data = doc.to_dict() or {}
    dt = parse_doc_datetime(data)

    resolved = bool(data.get("resolved", False)) or str(data.get("status", "")).strip().lower() in {
        "solved", "resolved", "completed", "complete", "closed", "done"
    }

    status = normalize_status(data.get("status"), resolved)
    image = get_valid_image_url(data)
    repair_image = normalize_public_image_url(data.get("repairImage") or data.get("repairImageUrl") or data.get("completionImage") or data.get("repairLocalPath") or "", preferred_folder="repairs")

    severity = str(data.get("severity") or data.get("detectionLabel") or "Moderate")
    if severity.lower() in {"pothole", "pothole detected"}:
        severity = "Moderate"

    return {
        "id": data.get("id") or doc.id,
        "title": data.get("title") or "Pothole Detected",
        "address": data.get("address") or "Unknown",
        "lat": safe_float(data.get("lat", data.get("latitude"))),
        "lng": safe_float(data.get("lng", data.get("longitude"))),
        "severity": severity,
        "status": status,
        "resolved": resolved,
        "image": image,
        "repairImage": repair_image,
        "date": dt.strftime("%Y-%m-%d %H:%M:%S"),
        "time": dt.strftime("%Y-%m-%d %H:%M:%S"),
        "location": data.get("address") or "Unknown",
        "accident": bool(data.get("accident", False)),
        "updatedAt": str(data.get("updated_at", "")),
        "resolvedAt": str(data.get("resolvedAt", "")),
    }


def get_pothole_collection_name() -> str:
    for name in POTHOLE_COLLECTION_CANDIDATES:
        try:
            docs = list(db.collection(name).limit(1).stream())
            if docs:
                print(f"[FIRESTORE] Using collection: {name}")
                return name
        except Exception as e:
            print(f"[FIRESTORE] Failed checking collection '{name}': {e}")

    print(f"[FIRESTORE] No non-empty collection found, defaulting to: {POTHOLE_COLLECTION_CANDIDATES[0]}")
    return POTHOLE_COLLECTION_CANDIDATES[0]


def pothole_collection():
    return db.collection(get_pothole_collection_name())


def get_all_pothole_docs():
    docs = list(pothole_collection().stream())
    print(f"[FIRESTORE] Pothole docs fetched: {len(docs)}")
    return docs


@app.route("/")
def home():
    return render_template("index.html")


@app.route("/uploads/<path:subpath>")
def uploaded_file(subpath):
    return send_from_directory(UPLOAD_ROOT, subpath)


@app.route("/api/session")
def get_session_state():
    return jsonify({
        "logged_in": bool(session.get("user")),
        "user": session.get("user"),
        "role": session.get("role", "")
    })


@app.route("/api/debug-potholes")
def debug_potholes():
    collection_name = get_pothole_collection_name()
    docs = list(db.collection(collection_name).stream())
    return jsonify({
        "collection": collection_name,
        "count": len(docs),
        "ids": [doc.id for doc in docs]
    })


@app.route("/api/complaints")
def get_complaints():
    docs = get_all_pothole_docs()
    items = [normalize_pothole(doc) for doc in docs]
    active = [x for x in items if not x["resolved"]]
    active.sort(key=lambda x: x["date"], reverse=True)
    return jsonify(active)


@app.route("/api/potholes")
def get_potholes():
    docs = get_all_pothole_docs()
    items = [normalize_pothole(doc) for doc in docs]
    items.sort(key=lambda x: x["date"], reverse=True)
    return jsonify(items)


@app.route("/api/home-summary")
def home_summary():
    docs = get_all_pothole_docs()
    items = [normalize_pothole(doc) for doc in docs]

    today = datetime.now().date()
    week_ago = datetime.now() - timedelta(days=7)

    complaints_today = 0
    severe_cases = 0
    solved_this_week = 0

    for item in items:
        item_dt = datetime.strptime(item["date"], "%Y-%m-%d %H:%M:%S")
        if item_dt.date() == today and not item["resolved"]:
            complaints_today += 1
        if (not item["resolved"]) and str(item["severity"]).lower() in {"dangerous", "severe", "high"}:
            severe_cases += 1
        if item_dt >= week_ago and item["resolved"]:
            solved_this_week += 1

    return jsonify({
        "complaintsToday": complaints_today,
        "severeCases": severe_cases,
        "solvedThisWeek": solved_this_week
    })


@app.route("/api/stats")
def stats():
    docs = get_all_pothole_docs()
    items = [normalize_pothole(doc) for doc in docs]

    total = len(items)
    pending_items = [x for x in items if not x["resolved"]]
    solved_count = total - len(pending_items)
    pending = len(pending_items)

    # Complaint counters shown in the authority dashboard represent
    # Firestore complaints that are still not solved. This keeps every
    # complaint number consistent across cards, donut, and live widgets.
    severity = {"minor": 0, "moderate": 0, "severe": 0}
    for item in pending_items:
        sev = str(item.get("severity", "")).strip().lower()
        if sev in {"dangerous", "severe", "high"}:
            severity["severe"] += 1
        elif sev in {"moderate", "medium"}:
            severity["moderate"] += 1
        else:
            severity["minor"] += 1

    return jsonify({
        "total_predictions": total,
        "accuracy_rate": 94.7,
        "total_complaints": pending,
        "pending_action": pending,
        "unsolved_complaints": pending,
        "resolved_complaints": solved_count,
        "total_reports": total,
        "all_reports": total,
        "severity": severity
    })

@app.route("/api/solved")
def solved():
    docs = get_all_pothole_docs()
    items = [normalize_pothole(doc) for doc in docs]
    solved_items = [x for x in items if x["resolved"]]
    solved_items.sort(key=lambda x: x["date"], reverse=True)
    return jsonify(solved_items)


@app.route("/api/update-status/<doc_id>", methods=["POST"])
def update_status(doc_id):
    if not require_role("constructor"):
        return jsonify({"success": False, "message": "Only road constructors can update pothole status."}), 403

    try:
        payload = request.form if request.form else (request.get_json(silent=True) or {})
        status = normalize_status(payload.get("status"), False)
        mark_resolved = status == "Solved"

        update_payload = {
            "status": status,
            "updated_at": datetime.utcnow().isoformat()
        }

        if mark_resolved:
            repair_image = ""
            if "repairImage" in request.files:
                repair_image = save_uploaded_file(request.files["repairImage"], "repairs")
            elif payload.get("repairImage"):
                repair_value = str(payload.get("repairImage"))
                repair_image = save_base64_image(repair_value, "repairs") if repair_value.startswith("data:image/") else repair_value

            if not repair_image:
                return jsonify({"success": False, "message": "Repair completed status requires a pothole work photo."}), 400

            update_payload.update({
                "resolved": True,
                "status": "Solved",
                "repairImage": repair_image,
                "resolvedAt": datetime.utcnow().isoformat(),
                "resolvedBy": session.get("user", "constructor")
            })
        else:
            update_payload.update({"resolved": False})

        pothole_collection().document(doc_id).update(update_payload)
        updated_doc = pothole_collection().document(doc_id).get()
        return jsonify({"success": True, "item": normalize_pothole(updated_doc)})

    except Exception as e:
        return jsonify({"success": False, "message": str(e)}), 500


@app.route("/api/admin/clear-old-potholes", methods=["POST"])
def clear_old_potholes():
    if not require_role("admin"):
        return jsonify({"success": False, "message": "Only admin can remove old pothole records."}), 403

    try:
        docs = get_all_pothole_docs()
        deleted = 0
        for doc in docs:
            doc.reference.delete()
            deleted += 1

        return jsonify({
            "success": True,
            "deleted": deleted,
            "message": f"Removed {deleted} old pothole records."
        })

    except Exception as e:
        return jsonify({"success": False, "message": str(e)}), 500


@app.route("/api/login/user", methods=["POST"])
def user_login():
    data = request_payload()
    email = data.get("email", "").strip().lower()
    password = data.get("password", "")

    user = get_user_by_email(email)
    if not user or user.get("password") != password:
        return jsonify({"success": False, "message": "Invalid user credentials."}), 401

    role = str(user.get("role", "user")).strip().lower() or "user"
    set_login_session(email, role)
    return jsonify({"success": True, "message": "User login successful.", "role": role})


@app.route("/api/login/admin", methods=["POST"])
def admin_login():
    data = request_payload()
    email = data.get("email", "").strip().lower()
    password = data.get("password", "")

    if email == ADMIN["email"] and password == ADMIN["password"]:
        set_login_session(email, "admin")
        return jsonify({"success": True, "message": "Admin login successful.", "role": "admin"})

    return jsonify({"success": False, "message": "Invalid admin credentials."}), 401


@app.route("/api/login/constructor", methods=["POST"])
def constructor_login():
    data = request_payload()
    email = data.get("email", "").strip().lower()
    password = data.get("password", "")

    if email == CONSTRUCTOR["email"] and password == CONSTRUCTOR["password"]:
        set_login_session(email, "constructor")
        return jsonify({"success": True, "message": "Road constructor login successful.", "role": "constructor"})

    user = get_user_by_email(email)
    if not user or user.get("password") != password:
        return jsonify({"success": False, "message": "Invalid constructor credentials."}), 401

    role = str(user.get("role", "constructor")).strip().lower() or "constructor"
    if role in {"authority", "road_constructor"}:
        role = "constructor"

    if role != "constructor":
        return jsonify({"success": False, "message": "This account is not allowed for Authority login."}), 403

    approval_status = normalize_authority_approval_status(user)
    if approval_status == "pending":
        return jsonify({"success": False, "message": "Your Authority account is waiting for admin approval."}), 403
    if approval_status == "rejected":
        return jsonify({"success": False, "message": "Your Authority signup request was rejected by admin."}), 403

    set_login_session(email, "constructor")
    return jsonify({"success": True, "message": "Authority login successful.", "role": "constructor"})


@app.route("/api/login/authority", methods=["POST"])
def authority_login():
    return constructor_login()


@app.route("/api/forgot-password/authority", methods=["POST"])
def forgot_password_authority():
    data = request_payload()
    email = str(data.get("email", "")).strip().lower()
    new_password = str(data.get("newPassword") or data.get("password") or "").strip()
    confirm_password = str(data.get("confirmPassword") or "").strip()

    if not email or not new_password or not confirm_password:
        return jsonify({"success": False, "message": "Email, new password and confirm password are required."}), 400

    if len(new_password) < 6:
        return jsonify({"success": False, "message": "Password must contain at least 6 characters."}), 400

    if new_password != confirm_password:
        return jsonify({"success": False, "message": "New password and confirm password do not match."}), 400

    user = get_user_by_email(email)
    if not user:
        return jsonify({"success": False, "message": "No Authority account found with this email."}), 404

    role = str(user.get("role", "")).strip().lower()
    if role not in {"constructor", "authority", "road_constructor"}:
        return jsonify({"success": False, "message": "This email is not registered as an Authority account."}), 403

    approval_status = normalize_authority_approval_status(user)
    if approval_status == "pending":
        return jsonify({"success": False, "message": "Your Authority account is still waiting for admin approval."}), 403
    if approval_status == "rejected":
        return jsonify({"success": False, "message": "Your Authority account was rejected by admin."}), 403

    db.collection("users").document(user["id"]).update({
        "password": new_password,
        "passwordUpdatedAt": datetime.utcnow().isoformat()
    })

    return jsonify({"success": True, "message": "Authority password updated successfully. Please login with the new password."})


@app.route("/api/signup", methods=["POST"])
def signup():
    data = request_payload()
    email = str(data.get("email", "")).strip().lower()
    password = str(data.get("password", "")).strip()
    requested_role = str(data.get("role", "constructor")).strip().lower() or "constructor"

    if requested_role in {"authority", "road_constructor"}:
        requested_role = "constructor"
    elif requested_role not in {"constructor", "user", "admin"}:
        requested_role = "constructor"

    if not email or not password:
        return jsonify({"success": False, "message": "Email and password are required."}), 400

    if get_user_by_email(email):
        return jsonify({"success": False, "message": "User already exists."}), 409

    db.collection("users").add({
        "email": email,
        "password": password,
        "role": requested_role,
        "created_at": datetime.utcnow().isoformat()
    })

    set_login_session(email, requested_role)
    return jsonify({
        "success": True,
        "message": "Account created successfully.",
        "role": requested_role
    })


@app.route("/api/signup/authority", methods=["POST"])
def authority_signup():
    payload = request_payload()
    email = str(payload.get("email", "")).strip().lower()
    password = str(payload.get("password", "")).strip()

    if not email or not password:
        return jsonify({"success": False, "message": "Email and password are required."}), 400

    if get_user_by_email(email):
        return jsonify({"success": False, "message": "User already exists."}), 409

    id_proof_url = ""
    if "idProof" in request.files and request.files["idProof"].filename:
        id_proof_url = save_uploaded_file(request.files["idProof"], "authority_ids")
    elif payload.get("idProof"):
        id_value = str(payload.get("idProof"))
        id_proof_url = save_base64_image(id_value, "authority_ids") if id_value.startswith("data:image/") else normalize_public_image_url(id_value, preferred_folder="authority_ids")

    db.collection("users").add({
        "email": email,
        "password": password,
        "role": "constructor",
        "approvalStatus": "pending",
        "idProofUrl": id_proof_url,
        "created_at": datetime.utcnow().isoformat()
    })

    session.clear()
    return jsonify({
        "success": True,
        "message": "Authority signup request submitted. Please wait for admin approval.",
        "role": "constructor",
        "approvalStatus": "pending"
    })


@app.route("/api/admin/pending-authorities")
def pending_authorities():
    if not require_role("admin"):
        return jsonify([])

    docs = db.collection("users").stream()
    items = []
    for doc in docs:
        user = doc.to_dict() or {}
        if normalize_authority_approval_status(user) != "pending":
            continue

        created_at = user.get("created_at") or user.get("createdAt") or ""
        items.append({
            "id": doc.id,
            "email": user.get("email", ""),
            "role": user.get("role", "constructor"),
            "approvalStatus": "pending",
            "idProofUrl": normalize_public_image_url(user.get("idProofUrl") or user.get("idProof") or user.get("proofOfId"), preferred_folder="authority_ids"),
            "created_at": str(created_at)
        })

    items.sort(key=lambda item: item.get("created_at", ""), reverse=True)
    return jsonify(items)


@app.route("/api/admin/authority-approval/<user_id>", methods=["POST"])
def authority_approval_action(user_id):
    if not require_role("admin"):
        return jsonify({"success": False, "message": "Only admin can review Authority signups."}), 403

    payload = request_payload()
    action = str(payload.get("action", "")).strip().lower()
    if action not in {"approve", "reject"}:
        return jsonify({"success": False, "message": "Invalid approval action."}), 400

    update_payload = {
        "approvalStatus": "approved" if action == "approve" else "rejected",
        "approvalUpdatedAt": datetime.utcnow().isoformat()
    }
    db.collection("users").document(user_id).update(update_payload)

    message = "Authority signup approved successfully." if action == "approve" else "Authority signup rejected successfully."
    return jsonify({"success": True, "message": message})


@app.route("/api/feedback", methods=["GET", "POST"])
def feedback():
    if request.method == "GET":
        if not require_role("admin"):
            return jsonify([])

        docs = db.collection("feedback").order_by("created_at", direction="DESCENDING").stream()
        items = []
        for doc in docs:
            data = doc.to_dict() or {}
            items.append({
                "id": doc.id,
                "name": data.get("name", ""),
                "email": data.get("email", ""),
                "role": data.get("role", ""),
                "issue": data.get("issue", ""),
                "message": data.get("message", ""),
                "created_at": data.get("created_at", "")
            })
        return jsonify(items)

    if not require_role("constructor", "admin"):
        return jsonify({"success": False, "message": "Please log in to send feedback."}), 403

    payload = request_payload()
    issue = str(payload.get("issue", "")).strip()
    message = str(payload.get("message", "")).strip()
    name = str(payload.get("name", "")).strip()

    if not issue or not message:
        return jsonify({"success": False, "message": "Please enter issue and details."}), 400

    db.collection("feedback").add({
        "name": name,
        "email": session.get("user", ""),
        "role": session.get("role", ""),
        "issue": issue,
        "message": message,
        "created_at": datetime.utcnow().isoformat()
    })
    return jsonify({"success": True, "message": "Feedback submitted successfully."})


@app.route("/api/logout", methods=["POST"])
def logout():
    session.clear()
    return jsonify({"success": True})


if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000, debug=True)